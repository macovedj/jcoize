export namespace WasiCliTerminalOutput {
  export { TerminalOutput };
}

export class TerminalOutput {
}
