export namespace WasiCliTerminalStdout {
  export function getTerminalStdout(): TerminalOutput | undefined;
}
import type { TerminalOutput } from '../interfaces/wasi-cli-terminal-output.js';
export { TerminalOutput };
