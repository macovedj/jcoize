export namespace WasiSocketsTcp {
  export { TcpSocket };
}

export class TcpSocket {
}
