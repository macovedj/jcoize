export namespace WasiCliEnvironment {
  export function getEnvironment(): [string, string][];
}
